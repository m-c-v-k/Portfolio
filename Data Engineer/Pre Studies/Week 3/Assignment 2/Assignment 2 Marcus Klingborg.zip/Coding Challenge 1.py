#! Python3

# Coding Challenge 1 – For-loops

# Write a program that outputs the numbers from 50 to 0 in the console. Use the range() function
# together with a for-loop.

# Loop
for x in range(50, -1, -1):
    print(x)
